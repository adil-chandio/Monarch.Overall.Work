Character 3D draft

This is a static, approximate face-textured prototype, not a photoreal scan or exact likeness. No skeleton, animation, physics or clothing simulation is embedded. The GLB includes the face reference image; this file is hosted in a public repository.
